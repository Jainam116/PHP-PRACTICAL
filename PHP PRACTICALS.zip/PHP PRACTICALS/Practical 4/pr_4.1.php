<!DOCTYPE html>
<html>
<head>
    <title>Car Company Finder</title>
</head>
<body>
    <h2>===========================</h2>
    <h2>JAINAM KHARA (216090307055)</h2>
    <h2>===========================</h2>
    <form method="POST">
        <br><label>Enter the name of the car:</label>
        <input type="text" name="car"><br><br>
        <button type="submit">Submit</button>
    </form>

    <?php
        if (isset($_POST["car"])) {
            $car = $_POST["car"];
            $company = "";

            switch ($car) {
                case "Safari":
                case "Nexon":
                case "Tigor":
                case "Tiago":
                    $company = "Tata";
                    break;
                case "XUV700":
                case "XUV300":
                case "Bolero":
                    $company = "Mahindra";
                    break;
                case "i20":
                case "Verna":
                case "Venue":
                case "Creta":
                    $company = "Hyundai";
                    break;
                case "Swift":
                case "Alto":
                case "Baleno":
                case "Brezza":
                    $company = "Suzuki";
                    break;
                default:
                    echo "<br>Invalid Car name.";
            }

            if (!empty($company)) {
                echo "<br>The Car $car belongs to $company.";
            }
        }
    ?>

</body>
</html>
