<!DOCTYPE html>
<html>
<head>
    <title>Result Calculator</title>
</head>
<body>
    <h2>===========================</h2>
    <h2>JAINAM KHARA (216090307055)</h2>
    <h2>===========================</h2>
    <form method="POST">
        <label>Enter Marks for Subject 1:</label>
        <input type="number" name="sub1" required><br><br>
        <label>Enter Marks for Subject 2:</label>
        <input type="number" name="sub2" required><br><br>
        <label>Enter Marks for Subject 3:</label>
        <input type="number" name="sub3" required><br><br>
        <label>Enter Marks for Subject 4:</label>
        <input type="number" name="sub4" required><br><br>
        <button type="submit">Submit</button>
    </form>

<?php
    if (isset($_POST["sub1"]) && isset($_POST["sub2"]) && isset($_POST["sub3"]) && isset($_POST["sub4"])) {
        $sub1 = $_POST["sub1"];
        $sub2 = $_POST["sub2"];
        $sub3 = $_POST["sub3"];
        $sub4 = $_POST["sub4"];

        $total_marks = 400;
        $obtained_marks = $sub1 + $sub2 + $sub3 + $sub4;
        $percentage = ($obtained_marks / $total_marks) * 100;

        echo "<br><h2>Result:</h2><br>";
        echo "<table border='1'>";
        echo "<tr><th>Subject</th><th>Marks</th><th>Grade</th></tr>";

        $subjects = array("Subject 1", "Subject 2", "Subject 3", "Subject 4");
        $marks = array($sub1, $sub2, $sub3, $sub4);

        for ($i = 0; $i < 4; $i++) {
            echo "<tr><td>" . $subjects[$i] . "</td><td>" . $marks[$i] . "</td><td>" . get_grade($marks[$i]) . "</td></tr>";
        }

        echo "</table><br>";

        echo "Total Marks Obtained: " . $obtained_marks . "<br>";
        echo "Percentage: " . number_format($percentage, 2) . "%<br>";
        echo "Grade: " . get_grade($percentage);
    }

    function get_grade($marks) {
        if ($marks >= 85 && $marks <= 100) {
            return "AA";
        } elseif ($marks >= 75 && $marks <= 84) {
            return "AB";
        } elseif ($marks >= 65 && $marks <= 74) {
            return "BB";
        } elseif ($marks >= 55 && $marks <= 64) {
            return "BC";
        } elseif ($marks >= 45 && $marks <= 54) {
            return "CC";
        } elseif ($marks >= 40 && $marks <= 44) {
            return "CD";
        } elseif ($marks >= 35 && $marks <= 39) {
            return "DD";
        } else {
            return "FF (FAIL)";
        }
    }
?>

</body>
</html>
