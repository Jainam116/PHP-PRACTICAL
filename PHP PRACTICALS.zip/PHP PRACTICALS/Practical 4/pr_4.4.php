<!DOCTYPE html>
<html>
<head>
	<title>Multiplication Table</title>
</head>
<body>
	<h2>===========================</h2>
    <h2>JAINAM KHARA (216090307055)</h2>
    <h2>===========================</h2>
	<form method="post">
		<br><label>Enter a number:</label>
		<input type="number" name="num" required><br><br>
		<button type="submit" name="submit">Generate Table</button>
	</form>

	<?php
	// function to generate multiplication table for a given number
	function multiplicationTable($num) {
		echo "<h2>Multiplication Table for $num:</h2>";
		echo "<table border='1'>";
		for ($i = 1; $i <= 10; $i++) {
			echo "<tr>";
			echo "<td>$num x $i</td>";
			echo "<td>" . ($num * $i) . "</td>";
			echo "</tr>";
		}
		echo "</table>";
	}

	// check if the form has been submitted
	if (isset($_POST['submit'])) {
		$num = $_POST['num'];
		multiplicationTable($num);
	}
	?>
</body>
</html>
