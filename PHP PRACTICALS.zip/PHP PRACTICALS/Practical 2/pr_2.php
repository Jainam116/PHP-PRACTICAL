<!DOCTYPE html>
<html>
<head>
   <title>User Information Form</title>
</head>
<body>

   <h2>===========================</h2>
   <h2>JAINAM KHARA (216090307055)</h2>
   <h2>===========================</h2>


   <h2>User Information Form</h2>

   

   <form method="post" action="">
      <label for="name">Name:</label>
      <input type="text" name="name" id="name" required><br><br>

      <label for="email">Email:</label>
      <input type="email" name="email" id="email" required><br><br>

      <label for="phone">Phone:</label>
      <input type="tel" name="phone" id="phone" required><br><br>

      <input type="submit" name="submit" value="Submit"><br><br>
   </form>

   <?php
      if(isset($_POST['submit'])){
         $name = $_POST['name'];
         $email = $_POST['email'];
         $phone = $_POST['phone'];

         echo "<h2>User Information:</h2>";
         echo "Name: " . $name . "<br><br>";
         echo "Email: " . $email . "<br><br>";
         echo "Phone: " . $phone . "<br><br>";
      }
   ?>
</body>
</html>
