<!DOCTYPE html>
<html>
<head>
	<title>Salary Calculator</title>
</head>
<body>
	<h2>===========================</h2>
    <h2>JAINAM KHARA (216090307055)</h2>
   	<h2>===========================</h2>
	<form method="post" action="">
		<label for="salary">Enter Basic Salary:</label>
		<input type="number" id="salary" name="salary" required><br><br>
		<input type="submit" value="Calculate Net Salary">
	</form>

	<?php
	if (isset($_POST['salary'])) {
		// get the basic salary from user input
		$basic_salary = $_POST['salary'];

		// calculate the gross salary components
		$da = 0.5 * $basic_salary;
		$hra = 0.1 * $basic_salary;
		$medical = 0.04 * $basic_salary;
		$gross_salary = $basic_salary + $da + $hra + $medical;

		// calculate the deduction components
		$insurance = 0.07 * $gross_salary;
		$pf = 0.05 * $gross_salary;
		$deduction = $insurance + $pf;

		// calculate the net salary
		$net_salary = $gross_salary - $deduction;

		// display the results
		echo "<br>Basic Salary: " . $basic_salary . "<br>";
		echo "Dearness Allowance (DA): " . $da . "<br>";
		echo "House Rent Allowance (HRA): " . $hra . "<br>";
		echo "Medical: " . $medical . "<br>";
		echo "Gross Salary: " . $gross_salary . "<br>";
		echo "Insurance: " . $insurance . "<br>";
		echo "Provident Fund (PF): " . $pf . "<br>";
		echo "Deduction: " . $deduction . "<br>";
		echo "<b>Net Salary: " . $net_salary . "</b>";
	}
	?>
</body>
</html>
