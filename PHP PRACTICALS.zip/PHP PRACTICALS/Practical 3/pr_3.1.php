<!DOCTYPE html>
<html>
<head>
	<title>Calculator</title>
</head>
<body>
	<h2>===========================</h2>
    <h2>JAINAM KHARA (216090307055)</h2>
   	<h2>===========================</h2>
   	<h2>Simple Calculator</h2>
	<form method="post">
		<label>Enter first number:</label>
		<input type="number" name="num1"><br><br>
		<label>Enter second number:</label>
		<input type="number" name="num2"><br><br>
		<label>Select operation:</label><br>
		<input type="radio" name="operator" value="+"> Addition<br>
  		<input type="radio" name="operator" value="-"> Subtraction<br>
  		<input type="radio" name="operator" value="*"> Multiplication<br>
  		<input type="radio" name="operator" value="/"> Division<br><br>
		<input type="submit" value="Calculate">
	</form>

	<?php
		if(isset($_POST['num1']) && isset($_POST['num2']) && isset($_POST['operator'])){
			$num1 = $_POST['num1'];
			$num2 = $_POST['num2'];
			$operator = $_POST['operator'];
			switch ($operator) {
				case "+":
					$result = $num1 + $num2;
					break;
				case "-":
					$result = $num1 - $num2;
					break;
				case "*":
					$result = $num1 * $num2;
					break;
				case "/":
					if ($num2 == 0) {
						echo "Error: Division by zero";
					} else {
						$result = $num1 / $num2;
					}
					break;
				default:
					echo "Error: Invalid operator";
			}
			if(isset($result)){
				echo "<h3>Result:  $result</h3>";
			}
		}
	?>
</body>
</html>
