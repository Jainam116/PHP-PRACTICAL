
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>encode into equivalent Morse code</title>
</head>
<body>
    <h2>===========================</h2>
    <h2>JAINAM KHARA (216090307055)</h2>
    <h2>===========================</h2>
    <?php
    // define the Morse code array
    $morseCode = array(
        'A' => '.-',    
        'B' => '-...',  
        'C' => '-.-.',  
        'D' => '-..',   
        'E' => '.',     
        'F' => '..-.',  
        'G' => '--.',   
        'H' => '....',  
        'I' => '..',    
        'J' => '.---',  
        'K' => '-.-',   
        'L' => '.-..',  
        'M' => '--',    
        'N' => '-.',    
        'O' => '---',   
        'P' => '.--.',  
        'Q' => '--.-',  
        'R' => '.-.',   
        'S' => '...',   
        'T' => '-',     
        'U' => '..-',   
        'V' => '...-',  
        'W' => '.--',   
        'X' => '-..-',  
        'Y' => '-.--',  
        'Z' => '--..',  
        '0' => '-----',
        '1' => '.----',
        '2' => '..---',
        '3' => '...--',
        '4' => '....-',
        '5' => '.....',
        '6' => '-....',
        '7' => '--...',
        '8' => '---..',
        '9' => '----.',
        '.' => '.-.-.-',
        ',' => '--..--',
        '?' => '..--..',
        '!' => '-.-.--'
    );

    // define the input message
    $message = 'HELLO WORLD!';
    echo "Original Message : $message<br><br>";

    // convert the message to uppercase
    $message = strtoupper($message);

    // loop through the characters in the message and encode each character to Morse code
    $morseMessage = '';
    for ($i = 0; $i < strlen($message); $i++) {
        $char = $message[$i];
        if (isset($morseCode[$char])) {
            $morseMessage .= $morseCode[$char] . ' ';
        } else {
            $morseMessage .= '  '; // add two spaces for non-alphanumeric characters
        }
    }

    // display the Morse code message
    echo "$message in Morse code : $morseMessage";
    ?>


</body>
</html>