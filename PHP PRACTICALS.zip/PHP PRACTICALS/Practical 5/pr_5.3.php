<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>3 x 3 matrix Multiplication.</title>
</head>
<body>
    <h2>===========================</h2>
    <h2>JAINAM KHARA (216090307055)</h2>
    <h2>===========================</h2>
    <?php

    // define the matrices
    $matrix1 = array(
        array(1, 2, 3),
        array(4, 5, 6),
        array(7, 8, 9)
    );

    $matrix2 = array(
        array(9, 8, 7),
        array(6, 5, 4),
        array(3, 2, 1)
    );

    // initialize the result matrix with zeros
    $result = array(
        array(0, 0, 0),
        array(0, 0, 0),
        array(0, 0, 0)
    );

    // perform matrix multiplication
    for ($i = 0; $i < 3; $i++) {
        for ($j = 0; $j < 3; $j++) {
            for ($k = 0; $k < 3; $k++) {
                $result[$i][$j] += $matrix1[$i][$k] * $matrix2[$k][$j];
            }
        }
    }

    // print the matrices
    echo "Matrix 1:<br>";
    printMatrix($matrix1);

    echo "Matrix 2:<br>";
    printMatrix($matrix2);

    echo "Result Matrix:<br>";
    printMatrix($result);

    // function to print a matrix
    function printMatrix($matrix) {
        for ($i = 0; $i < 3; $i++) {
            for ($j = 0; $j < 3; $j++) {
                echo $matrix[$i][$j] . " ";
            }
            echo "<br>";
        }
        echo "<br>";
    }

    ?>

</body>
</html>