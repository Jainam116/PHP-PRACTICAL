<!DOCTYPE html>
<html>
<head>
	<title>String Length and Word Count</title>
</head>
<body>
	<form method="post">
		<h2>===========================</h2>
    	<h2>JAINAM KHARA (216090307055)</h2>
    	<h2>===========================</h2>
		<br><label>Enter a string:</label>
		<input type="text" name="input_string" required><br><br>
		<button type="submit" name="submit">Calculate</button>
	</form>

	<?php
	// function to calculate string length and word count without using string functions
	function calculate($str) {
		$length = 0;
		$word_count = 0;

		// iterate over each character in the string
		for ($i = 0; isset($str[$i]); $i++) {
			// count the number of characters
			$length++;

			// if the current character is a space or a newline, increment the word count
			if ($str[$i] == ' ' || $str[$i] == "\n") {
				$word_count++;
			}
		}

		// add one to the word count for the last word
		$word_count++;

		return array($length, $word_count);
	}

	// check if the form has been submitted
	if (isset($_POST['submit'])) {
		$input_string = $_POST['input_string'];
		list($length, $word_count) = calculate($input_string);
		echo "<h2>Result:</h2>";
		echo "<p>The string is: $input_string</p>";
		echo "<p>Length of the string: $length</p>";
		echo "<p>Number of words in the string: $word_count</p>";	}
	?>
</body>
</html>
