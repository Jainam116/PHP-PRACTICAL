<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Unsorted to Sorted Array</title>
</head>
<body>
   <h2>===========================</h2>
   <h2>JAINAM KHARA (216090307055)</h2>
   <h2>===========================</h2>

    <?php
    // define an indexed array
    $numbers = array(10, 5, 8, 2, 7);

    echo "Unsorted Array:<br>";
    print_r($numbers);

    // sort the array using bubble sort
    $n = count($numbers);
    for ($i = 0; $i < $n - 1; $i++) {
        for ($j = 0; $j < $n - $i - 1; $j++) {
            if ($numbers[$j] > $numbers[$j+1]) {
                // swap the elements
                $temp = $numbers[$j];
                $numbers[$j] = $numbers[$j+1];
                $numbers[$j+1] = $temp;
            }
        }
    }

    // display the sorted array
    echo "<br><br>Sorted Array:<br>";
    print_r($numbers);
    ?>

</body>
</html>















